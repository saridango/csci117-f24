COMPILE: g++ -std=c++11 prog3.cpp -o prog3
RUN: ./prog3

You may test the program with the four provided textfiles
by editing the filename in main().

Refer to the output screenshot for my testing results.
They are tested in order of:
prog3.txt
semantic_error.txt
syntax_error.txt
lexical_error.txt